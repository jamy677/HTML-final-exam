// Header content
const headerContent = `
    <section class="mainhead">
        <!-- ... header content ... -->
    </section>
`;

// Footer content
const footerContent = `
    <section class="footer">
        <!-- ... footer content ... -->
    </section>
`;

// Get header and footer elements
const headerElement = document.getElementById("global-header");
const footerElement = document.getElementById("global-footer");

// Set header and footer content
headerElement.innerHTML = headerContent;
footerElement.innerHTML = footerContent;
